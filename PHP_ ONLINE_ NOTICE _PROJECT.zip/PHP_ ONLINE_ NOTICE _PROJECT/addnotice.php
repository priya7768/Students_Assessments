<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/bootstrap.css"/>
		<script src="js/jquery_library.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>

    <?php
    extract($_POST);
    include 'dhp.php';
    if(isset($add))
    {

    	if($details=="" || $sub=="" || $user=="")
    	{
    	$err="<font color='red'>fill all the fileds first</font>";
    	}
    	else
    	{
    		foreach($user as $v)
    		{
    mysqli_query($conn,"insert into notice values('','$v','$sub','$details',now())");
    		}

    		$err="<font color='green'>Notice added Successfully</font>";
    	}
    }

    ?>
    <div class="container-fulid ">
      <nav class="navbar navbar-default navbar-fixed-top" style="background:#000">
        <div class="container">

        <ul class="nav navbar-nav navbar-left">
          <li><a href="index1.php" style="color:white"><strong>Hello</strong></a></li>


        </ul>


      <ul class="nav navbar-nav navbar-right">
            <li><a href="logout.php" style="color:white"><span class="glyphicon glyphicon-user"></span> Logout</a></li>

          </ul>
        </div>
</nav>
</div><br><br><br>

<div class="container-fluid">

<div class="row">

  <div class="col-lg-3 lg-text-center">
      <h3 class="bg-info">User Profile</h3>
    <img src="images/person.jpg">

    <a href="change_password.php" class="fa fa-key"> change password</a><br><br>
    <a href="manage_user.php"  class="fa fa-user"> manage users</a><br><br>
    <a href="update_notice.php" class="fa fa-bell">update notice</a><br><br>


  </div>
  <div class="col-lg-9">


    <form method="post"style="text-align:center" >
<h2 style="text-align:center">Add New Notice</h2>
    	<div class="row">
    		<div class="col-sm-4"></div>
    		<div class="col-sm-4"><?php echo @$err;?></div>
    	</div>



    	<div class="row">
    		<div class="col-sm-4">Enter Subject</div>
    		<div class="col-sm-5">
    		<input type="text" name="sub" class="form-control"/></div>
    	</div>


    	<div class="row" style="margin-top:10px">
    		<div class="col-sm-2"></div>
    		<div class="col-sm-8">
    	</div>

    	<div class="row">
    		<div class="col-sm-4">Enter Details</div>
    		<div class="col-sm-5">
    		<textarea name="details" class="form-control"></textarea></div>
    	</div>


    	<div class="row" style="margin-top:10px">
    		<div class="col-sm-2"></div>
    		<div class="col-sm-8">
    	</div>

    	<div class="row">
    		<div class="col-sm-4">Select User</div>
    		<div class="col-sm-5">
    		<select name="user[]" multiple="multiple" class="form-control">
    			<?php
    	$sql=mysqli_query($conn,"select name,email from user");
    	while($r=mysqli_fetch_array($sql))
    	{
    		echo "<option value='".$r['email']."'>".$r['name']."</option>";
    	}
    			?>
    		</select>
    		</div>
    	</div>

    	<div class="row" style="margin-top:10px">
    		<div class="col-sm-2"></div>
    		<div class="col-sm-8">
    	</div>

    		<div class="row" style="margin-top:10px">
    		<div class="col-sm-2"></div>
    		<div class="col-sm-4">
    		<input type="submit" value="Add New Notice" name="add" class="btn btn-success"/>
    		<input type="reset" class="btn btn-success"/>
    		</div>
    	</div>
    </form>
  </div>

</div>

</div>












  </body>
</html>

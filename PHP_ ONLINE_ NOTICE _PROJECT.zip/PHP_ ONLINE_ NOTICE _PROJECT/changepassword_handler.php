<?php









  include 'dhp.php';
  if($conn){
  $op=$_POST['op'];

  $password=$_POST['password'];
$sql="update user set password='$password' where name='$op'";
$result=mysqli_query($conn,$sql);
if($result){
header ('location:login.php');

}

else{

echo"not updated";
}
}
else{

echo"error";
}


















 ?>
